<?php

class Setting extends ActiveRecord\Model {

}
