<?php

class Presentation extends ActiveRecord\Model {

}
