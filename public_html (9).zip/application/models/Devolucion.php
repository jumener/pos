<?php

class Devolucion extends ActiveRecord\Model {

}
