<?php

class Hold extends ActiveRecord\Model {

}
