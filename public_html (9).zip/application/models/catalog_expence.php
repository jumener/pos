<?php

class Catalog_expence extends ActiveRecord\Model {

	
}
