<?php

class Transfer_item extends ActiveRecord\Model {


}
