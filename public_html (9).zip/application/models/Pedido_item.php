<?php

class Pedido_item extends ActiveRecord\Model {


}
