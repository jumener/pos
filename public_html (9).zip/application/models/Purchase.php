<?php

class Purchase extends ActiveRecord\Model {


}
