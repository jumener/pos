<?php

class Remision extends ActiveRecord\Model {


}
