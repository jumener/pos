<?php

class Licencia extends ActiveRecord\Model {

}
