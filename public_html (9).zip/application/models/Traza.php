<?php

class Traza extends ActiveRecord\Model {

}
