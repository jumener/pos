<?php

class Purchase_item extends ActiveRecord\Model {


}
