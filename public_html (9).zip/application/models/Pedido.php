<?php

class Pedido extends ActiveRecord\Model {

}
