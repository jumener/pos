<?php

class Brand extends ActiveRecord\Model {

}
