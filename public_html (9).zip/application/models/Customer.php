<?php

class Customer extends ActiveRecord\Model {

}
