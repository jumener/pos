<?php

class Thirdparty extends ActiveRecord\Model {

}
