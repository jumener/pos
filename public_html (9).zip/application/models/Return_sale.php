<?php

class Return_sale extends ActiveRecord\Model {


}
