<?php

class Tax extends ActiveRecord\Model {

}
