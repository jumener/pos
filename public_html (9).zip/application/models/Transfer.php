<?php

class Transfer extends ActiveRecord\Model {


}
