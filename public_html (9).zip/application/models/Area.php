<?php

class Area extends ActiveRecord\Model {

}
