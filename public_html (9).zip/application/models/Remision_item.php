<?php

class Remision_item extends ActiveRecord\Model {


}
