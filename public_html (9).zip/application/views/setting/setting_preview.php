<!DOCTYPE html>
<html>
<head>
  <title>Setting View</title>
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    
    select {
      width: 200px;
    }
  </style>
</head>
<body>
  <?php echo form_open_multipart('settings?tab=setting'); ?>
  <button type="submit" class="btn btn-primary btn-lg"><?=label("Submit");?></button>
  <select onchange="redirect(this.value)" name="setting_id" id="setting_id">
    <option value=""><?=label("Store");?></option>
    <?php foreach ($settings_all as $store):?>
    <option value="<?=$store->id;?>"><?=$store->id;?></option>
    <?php endforeach;?>
  </select>
  <?php echo form_close(); ?>
</body>
</html>
