  <div class="container">    
    <div class="col-sm-12">
         <div class="row"> 
            <div class="col-sm-12 well" style="width: 100%; height: 350px; border: solid #666666 1px;  margin-top: 20px;">
              EN CONSTRUCCIÓN
            </div>
          </div>

    </div>
</div>
